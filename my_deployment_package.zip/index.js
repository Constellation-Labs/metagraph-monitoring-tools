import { SSMClient } from '@aws-sdk/client-ssm'
import { getDiffBetweenLastMetagraphSnapshotAndNow, killCurrentProcesses, printSeparator } from './shared.js'
import { restartL0Nodes } from './metagraph-l0.js'
import { restartCurrencyL1Nodes } from './currency-l1.js'
import { restartDataL1Nodes } from './data-l1.js'

const VALID_NETWORKS = ['mainnet', 'integrationnet', 'testnet']

export const handler = async (event) => {
  const { network, metagraph_id, region } = event
  if (!network || !metagraph_id || !region) {
    throw Error("region, network and metagraph_id are required.")
  }

  if (!VALID_NETWORKS.includes(network)) {
    throw Error(`Network should be one of the following: ${JSON.stringify(VALID_NETWORKS)}`)
  }

  const { ec2_instance_1_ip, ec2_instance_2_ip, ec2_instance_3_ip } = event;
  if (!ec2_instance_1_ip || !ec2_instance_2_ip || !ec2_instance_3_ip) {
    throw Error("All 3 ec2 instances IPs are required")
  }

  const { ec2_instance_1_id, ec2_instance_2_id, ec2_instance_3_id } = event;
  if (!ec2_instance_1_id || !ec2_instance_2_id || !ec2_instance_3_id) {
    throw Error("All 3 ec2 instances IDs are required")
  }

  const diffBetweenLastMetagraphSnapshotAndNow = await getDiffBetweenLastMetagraphSnapshotAndNow(network, metagraph_id)
  if (diffBetweenLastMetagraphSnapshotAndNow < 4) {
    return {
      statusCode: 200,
      body: JSON.stringify('Metagraph producing snapshots correctly, skipping.'),
    };
  }

  const ssmClient = new SSMClient({ region });
  console.log("\n\n############### STARTING THE RESTART ###################\n\n")
  
  printSeparator()
  console.log('Killing current processes on nodes')
  await killCurrentProcesses(ssmClient, event, [
    ec2_instance_1_id,
    ec2_instance_2_id,
    ec2_instance_3_id
  ])
  console.log('Killing current processes on nodes finished')
  printSeparator()

  console.log("################ METAGRAPH L0 ##################")
  const nodeId = await restartL0Nodes(ssmClient, event)
  console.log("################ FINISHED METAGRAPH L0 ##################\n\n\n\n")

  console.log("################ CURRENCY L1 ##################")
  await restartCurrencyL1Nodes(ssmClient, event, nodeId)
  console.log("################ FINISHED CURRENCY L1 ################## \n\n\n\n")

  console.log("################ DATA L1 ##################")
  await restartDataL1Nodes(ssmClient, event, nodeId)
  console.log("################ FINISHED DATA L1 ################## \n\n\n\n")

  const response = {
    statusCode: 200,
    body: JSON.stringify('Finished cluster restart'),
  };

  return response;
};