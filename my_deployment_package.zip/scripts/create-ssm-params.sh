#!/bin/bash
aws ssm put-parameter \
  --name "/metagraph-nodes/i-00e6ff6893a3fcba5/l0/keystore" \
  --value "bitforex-metagraph-1.p12" \
  --type "String" \
  --overwrite
aws ssm put-parameter \
  --name "/metagraph-nodes/i-00e6ff6893a3fcba5/l0/keyalias" \
  --value "ctt-metagraph-1" \
  --type "String" \
  --overwrite
aws ssm put-parameter \
  --name "/metagraph-nodes/i-00e6ff6893a3fcba5/l0/password" \
  --value "5VD5Z6*w17wo" \
  --type "String" \
  --overwrite
aws ssm put-parameter \
  --name "/metagraph-nodes/i-00e6ff6893a3fcba5/cl1/keystore" \
  --value "bitforex-metagraph.p12" \
  --type "String" \
  --overwrite
aws ssm put-parameter \
  --name "/metagraph-nodes/i-00e6ff6893a3fcba5/cl1/keyalias" \
  --value "bitforex-metagraph" \
  --type "String" \
  --overwrite
aws ssm put-parameter \
  --name "/metagraph-nodes/i-00e6ff6893a3fcba5/cl1/password" \
  --value "5VD5Z6*w17wo" \
  --type "String" \
  --overwrite
# aws ssm put-parameter \
#   --name "/metagraph-nodes/i-00e6ff6893a3fcba5/dl1/keystore" \
#   --value "metagraph_testnet.p12" \
#   --type "String" \
#   --overwrite
# aws ssm put-parameter \
#   --name "/metagraph-nodes/i-00e6ff6893a3fcba5/dl1/keyalias" \
#   --value "metagraph_testnet" \
#   --type "String" \
#   --overwrite
# aws ssm put-parameter \
#   --name "/metagraph-nodes/i-00e6ff6893a3fcba5/dl1/password" \
#   --value "password" \
#   --type "String" \
#   --overwrite

aws ssm put-parameter \
  --name "/metagraph-nodes/i-089c6076393c9445a/l0/keystore" \
  --value "bitforex-metagraph-2.p12" \
  --type "String" \
  --overwrite
aws ssm put-parameter \
  --name "/metagraph-nodes/i-089c6076393c9445a/l0/keyalias" \
  --value "ctt-metagraph-2" \
  --type "String" \
  --overwrite
aws ssm put-parameter \
  --name "/metagraph-nodes/i-089c6076393c9445a/l0/password" \
  --value "k2Y9%6e*RU6%" \
  --type "String" \
  --overwrite
aws ssm put-parameter \
  --name "/metagraph-nodes/i-089c6076393c9445a/cl1/keystore" \
  --value "bitforex-metagraph.p12" \
  --type "String" \
  --overwrite
aws ssm put-parameter \
  --name "/metagraph-nodes/i-089c6076393c9445a/cl1/keyalias" \
  --value "bitforex-metagraph" \
  --type "String" \
  --overwrite
aws ssm put-parameter \
  --name "/metagraph-nodes/i-089c6076393c9445a/cl1/password" \
  --value "k2Y9%6e*RU6%" \
  --type "String" \
  --overwrite
# aws ssm put-parameter \
#   --name "/metagraph-nodes/i-089c6076393c9445a/dl1/keystore" \
#   --value "metagraph_testnet.p12" \
#   --type "String" \
#   --overwrite
# aws ssm put-parameter \
#   --name "/metagraph-nodes/i-089c6076393c9445a/dl1/keyalias" \
#   --value "metagraph_testnet" \
#   --type "String" \
#   --overwrite
# aws ssm put-parameter \
#   --name "/metagraph-nodes/i-089c6076393c9445a/dl1/password" \
#   --value "password" \
#   --type "String" \
#   --overwrite

aws ssm put-parameter \
  --name "/metagraph-nodes/i-09483e068ef6664a7/l0/keystore" \
  --value "bitforex-metagraph-3.p12" \
  --type "String" \
  --overwrite
aws ssm put-parameter \
  --name "/metagraph-nodes/i-09483e068ef6664a7/l0/keyalias" \
  --value "ctt-metagraph-3" \
  --type "String" \
  --overwrite
aws ssm put-parameter \
  --name "/metagraph-nodes/i-09483e068ef6664a7/l0/password" \
  --value "4oxw60AT#O@x" \
  --type "String" \
  --overwrite
aws ssm put-parameter \
  --name "/metagraph-nodes/i-09483e068ef6664a7/cl1/keystore" \
  --value "bitforex-metagraph.p12" \
  --type "String" \
  --overwrite
aws ssm put-parameter \
  --name "/metagraph-nodes/i-09483e068ef6664a7/cl1/keyalias" \
  --value "bitforex-metagraph" \
  --type "String" \
  --overwrite
aws ssm put-parameter \
  --name "/metagraph-nodes/i-09483e068ef6664a7/cl1/password" \
  --value "4oxw60AT#O@x" \
  --type "String" \
  --overwrite
# aws ssm put-parameter \
#   --name "/metagraph-nodes/i-09483e068ef6664a7/dl1/keystore" \
#   --value "metagraph_testnet.p12" \
#   --type "String" \
#   --overwrite
# aws ssm put-parameter \
#   --name "/metagraph-nodes/i-09483e068ef6664a7/dl1/keyalias" \
#   --value "metagraph_testnet" \
#   --type "String" \
#   --overwrite
# aws ssm put-parameter \
#   --name "/metagraph-nodes/i-09483e068ef6664a7/dl1/password" \
#   --value "password" \
#   --type "String" \
#   --overwrite